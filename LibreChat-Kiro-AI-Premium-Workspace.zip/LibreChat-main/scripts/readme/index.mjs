#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import {
  LANGUAGES,
  buildMessages,
  cleanOutput,
  definitions,
  hash,
  isSwitcher,
  localizeAnchors,
  needsTranslation,
  renderSwitcher,
  reusable,
  splitChunks,
  validate,
} from './lib.mjs';

const SOURCE = 'README.md';
const CACHE = '.github/readme-i18n.json';
const ATTEMPTS = 3;
const CONCURRENCY = 4;

const args = process.argv.slice(2);
const force = args.includes('--force');
const langsArg = args.find((arg) => arg.startsWith('--langs='))?.slice('--langs='.length);
const langs = (langsArg || Object.keys(LANGUAGES).join(','))
  .split(',')
  .map((code) => code.trim())
  .filter(Boolean);

const baseUrl = process.env.README_TRANSLATE_BASE_URL?.replace(/\/+$/, '');
const apiKey = process.env.README_TRANSLATE_API_KEY;
const model = process.env.README_TRANSLATE_MODEL;
const missing = Object.entries({
  README_TRANSLATE_BASE_URL: baseUrl,
  README_TRANSLATE_API_KEY: apiKey,
  README_TRANSLATE_MODEL: model,
})
  .filter(([, value]) => !value)
  .map(([key]) => key);
if (missing.length > 0) {
  console.error(`Missing environment variables: ${missing.join(', ')}`);
  process.exit(2);
}
for (const code of langs) {
  if (!LANGUAGES[code]) {
    console.error(`Unsupported language: ${code}`);
    process.exit(2);
  }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function complete(code, chunk) {
  const response = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model, messages: buildMessages(LANGUAGES[code].name, chunk) }),
    signal: AbortSignal.timeout(120_000),
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const data = await response.json();
  const content = data?.choices?.[0]?.message?.content;
  if (typeof content !== 'string' || content.trim() === '') throw new Error('empty completion');
  return cleanOutput(content);
}

async function translate(code, chunk, context) {
  let reason = '';
  for (let attempt = 1; attempt <= ATTEMPTS; attempt += 1) {
    try {
      const output = await complete(code, chunk);
      const problems = validate(chunk, output, code, context);
      if (problems.length === 0) return output;
      reason = problems.join('; ');
    } catch (error) {
      reason = error instanceof Error ? error.message : 'request failed';
    }
    if (attempt < ATTEMPTS) await sleep(1000 * 2 ** (attempt - 1));
  }
  const preview = chunk.slice(0, 80).replace(/\s+/g, ' ');
  throw new Error(`${code} translation failed (${reason}) for: ${preview}`);
}

async function pool(items, worker) {
  const queue = [...items];
  await Promise.all(
    Array.from({ length: Math.min(CONCURRENCY, queue.length) }, async () => {
      while (queue.length > 0) await worker(queue.shift());
    }),
  );
}

const readIfExists = async (file) => readFile(file, 'utf8').catch(() => null);

const source = await readFile(SOURCE, 'utf8');
const units = splitChunks(source);
const chunks = units.map((unit) => unit.text);
const context = definitions(source);
const stored = JSON.parse((await readIfExists(CACHE)) ?? '{}');
const cache = { version: 1 };
const outputs = {};
const available = await Promise.all(
  Object.entries(LANGUAGES).map(async ([code, { file }]) =>
    langs.includes(code) || (await readIfExists(file)) !== null ? code : null,
  ),
).then((codes) => codes.filter(Boolean));

for (const code of langs) {
  const { file } = LANGUAGES[code];
  const previous = force ? {} : (stored[code] ?? {});
  const next = {};
  const pending = [];
  for (const chunk of chunks) {
    if (isSwitcher(chunk) || !needsTranslation(chunk, context)) continue;
    const key = hash(chunk);
    const cached = reusable(previous[key], chunk, code, context);
    if (cached !== undefined) next[key] = cached;
    else if (!pending.some((item) => item.key === key)) pending.push({ key, chunk });
  }
  console.log(
    `${code}: ${pending.length} chunk(s) to translate, ${Object.keys(next).length} cached`,
  );
  await pool(pending, async ({ key, chunk }) => {
    next[key] = await translate(code, chunk, context);
  });
  const assembled = units
    .map(({ text, joiner }, index) => {
      const part = isSwitcher(text) ? renderSwitcher(code, available) : text;
      const out = !isSwitcher(text) && needsTranslation(text, context) ? next[hash(text)] : part;
      return index === 0 ? out : joiner + out;
    })
    .join('');
  const body = localizeAnchors(source.replace(/\r\n/g, '\n'), assembled);
  const notice =
    '<!-- Generated from README.md by .github/workflows/readme-translate.yml. Do not edit by hand. -->';
  outputs[file] = `${notice}\n\n${body}\n`;
  cache[code] = Object.fromEntries(
    chunks
      .filter((chunk) => !isSwitcher(chunk) && needsTranslation(chunk, context))
      .map((chunk) => [hash(chunk), next[hash(chunk)]]),
  );
}

for (const code of Object.keys(LANGUAGES)) {
  if (!langs.includes(code) && stored[code]) cache[code] = stored[code];
}

// Languages not selected keep their body, but their switcher must list every available language.
for (const [code, { file }] of Object.entries(LANGUAGES)) {
  const existing = langs.includes(code) ? null : await readIfExists(file);
  const current = existing && splitChunks(existing).find((unit) => isSwitcher(unit.text));
  if (!current || current.text === renderSwitcher(code, available)) continue;
  outputs[file] = existing.replace(current.text, () => renderSwitcher(code, available));
}

const switcher = chunks.find(isSwitcher);
if (switcher && switcher !== renderSwitcher('en', available)) {
  outputs[SOURCE] = source.replace(switcher, () => renderSwitcher('en', available));
}

for (const [file, content] of Object.entries(outputs)) await writeFile(file, content);
await writeFile(CACHE, `${JSON.stringify(cache, null, 2)}\n`);

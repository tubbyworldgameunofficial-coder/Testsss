import { test } from 'node:test';
import { strict as assert } from 'node:assert';
import { findCssColorLiterals } from './css-colors.mts';

const literals = (css: string): string[] => findCssColorLiterals(css).map(({ literal }) => literal);

test('reports hex, numeric colour functions and named colours in values', () => {
  const css = [
    'a {',
    '  color: #0066cc;',
    '  background-color: rgba(0, 0, 0, 0.1);',
    '  border-color: hsl(10 20% 30%);',
    '  outline: 1px solid white;',
    '  --accent: #FFF;',
    '}',
  ].join('\n');
  assert.deepEqual(literals(css), ['#0066cc', 'rgba(0', 'hsl(1', 'white', '#FFF']);
});

test('accepts theme variables, comments, urls and selectors', () => {
  const css = [
    '/* was #0066cc and rgba(0, 0, 0, 0.1) */',
    '#fade, #root { color: rgb(var(--text-primary)); }',
    'a {',
    '  background: rgb(var(--black) / 0.1);',
    '  box-shadow: 0 1px 2px rgb(var(--slate-ink) / 0.3);',
    '  --on-white: var(--white);',
    '  border-color: theme(colors.gray.200);',
    "  background-image: url('sprite.svg#fff');",
    "  content: 'white';",
    '  transition: color 150ms ease;',
    '}',
  ].join('\n');
  assert.deepEqual(literals(css), []);
});

test('reports the line of each finding', () => {
  assert.deepEqual(findCssColorLiterals('a {\n  color: red;\n}\n'), [{ line: 2, literal: 'red' }]);
});

test('exempts only the named rule, not the rest of its file', () => {
  const css = [
    '.azure-bg-color {',
    '  background: linear-gradient(0.375turn, #61bde2, #4389d0);',
    '}',
    '.other {',
    '  color: #0066cc;',
    '}',
  ].join('\n');
  assert.deepEqual(literals(css), ['#61bde2', '#4389d0', '#0066cc']);
  assert.deepEqual(findCssColorLiterals(css, [{ selector: '.azure-bg-color' }]), [
    { line: 5, literal: '#0066cc' },
  ]);
});

test('reads declarations that share a line with a selector or continue onto another line', () => {
  assert.deepEqual(literals('.alert { color: #fff; }'), ['#fff']);
  assert.deepEqual(literals('a{box-shadow:0 1px 2px\n  rgb(0 0 0 / 0.1)}'), ['rgb(0']);
  assert.deepEqual(literals('@media (min-width: 1px) { a { color: red } }'), ['red']);
});

test('matches colour functions case-insensitively, including color()', () => {
  assert.deepEqual(literals('a { color: color(srgb 1 0 0); }'), ['color(srgb 1']);
  assert.deepEqual(literals('a { background: RGB(255 0 0); }'), ['RGB(2']);
  assert.deepEqual(literals('a { color: color(from var(--x) srgb r g b); }'), []);
});

test('covers the full named-colour set and upper-case property names', () => {
  assert.deepEqual(literals('a { color: rebeccapurple; }'), ['rebeccapurple']);
  assert.deepEqual(literals('a { COLOR: red; }'), ['red']);
  assert.deepEqual(literals('a { transition: tan 1s; }'), []);
});

test('reads signed and keyword components and names in any colour-bearing shorthand', () => {
  assert.deepEqual(literals('a { color: hsl(-10 20% 30%); }'), ['hsl(-']);
  assert.deepEqual(literals('a { color: rgb(none 0 0); }'), ['rgb(none']);
  assert.deepEqual(literals('a { filter: drop-shadow(0 0 1px red); }'), ['red']);
  assert.deepEqual(literals('a { text-decoration: underline red; }'), ['red']);
  assert.deepEqual(literals('a { transition: color 1s; animation: white 1s; }'), []);
});

test('strips URL functions and escaped strings whole, and reads mixed variable components', () => {
  assert.deepEqual(literals('a { background-image: URL(#fff); }'), []);
  assert.deepEqual(literals('a { content: "a\\"; color: #fff;"; }'), []);
  assert.deepEqual(literals('a { color: hsl(var(--hue) 100% 50%); }'), ['hsl(var(--hue) 1']);
  assert.deepEqual(literals('a { color: hsl(var(--h) var(--s) var(--l)); }'), []);
});

test('reports each occurrence on its own line and reads calc() and mask gradients', () => {
  assert.deepEqual(
    findCssColorLiterals('a {\n  background: linear-gradient(\n    red,\n    red\n  );\n}'),
    [
      { line: 3, literal: 'red' },
      { line: 4, literal: 'red' },
    ],
  );
  assert.deepEqual(literals('a { color: rgb(calc(255) 0 0); }'), ['rgb(calc(']);
  assert.deepEqual(literals('a { mask: linear-gradient(red, blue); }'), ['red', 'blue']);
});

test('reads colours inside inline data images but not external urls', () => {
  const arrow =
    'a { background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg stroke=\'%238e8ea0\'/%3E"); }';
  assert.deepEqual(literals(arrow), ['#8e8ea0']);
  assert.deepEqual(literals('a { background-image: url(sprite.svg#fff); }'), []);
});

test('limits an exception to one property and decodes base64 images', () => {
  const css =
    "select { background-image: url('data:image/svg+xml;base64,PHN2ZyBzdHJva2U9JyNmZmYnLz4='); color: red; }";
  const allowed = [{ selector: 'select', property: 'background-image' }];
  assert.deepEqual(literals(css), ['#fff', 'red']);
  assert.deepEqual(findCssColorLiterals(css, allowed), [{ line: 1, literal: 'red' }]);
});

test('reads comma-separated components after var() and ignores comments inside values', () => {
  assert.deepEqual(literals('a { color: hsl(var(--h), 100%, 50%); }'), ['hsl(var(--h), 1']);
  assert.deepEqual(literals('a { color: var(--text) /* fallback: #fff */; }'), []);
});

test('reads every CSS math function as a colour channel', () => {
  assert.deepEqual(literals('a { color: rgb(min(255, 300) 0 0); }'), ['rgb(min(']);
  assert.deepEqual(literals('a { color: hsl(clamp(0, 120, 360) 100% 50%); }'), ['hsl(clamp(']);
});

test('reads numeric colour profiles, whole function names and later channels after variables', () => {
  assert.deepEqual(literals('a { color: color(display-p3 1 0 0); }'), ['color(display-p3 1']);
  assert.deepEqual(literals('a { --value: my-rgb(0); }'), []);
  assert.deepEqual(literals('a { color: rgb(var(--r) var(--g) 0); }'), ['rgb(var(--r) var(--g) 0']);
  assert.deepEqual(literals('a { color: rgb(var(--c) / 0.5); }'), []);
});

test('reads later channels in color() and inspects only SVG data images', () => {
  assert.deepEqual(literals('a { color: color(display-p3 var(--r) 0 0); }'), [
    'color(display-p3 var(--r) 0',
  ]);
  assert.deepEqual(literals("a { background: url('data:image/png;base64,cmVk'); }"), []);
});

test('blanks comments embedded in values', () => {
  assert.deepEqual(
    literals('a { background: linear-gradient(/* red to blue */ var(--a), var(--b)); }'),
    [],
  );
  assert.equal(literals('a { color: rgb(/* note */ 255 0 0); }').length, 1);
});

test('reads fixed channels in relative colours but not pure relative forms', () => {
  assert.equal(literals('a { color: rgb(from var(--base) 255 g b); }').length, 1);
  assert.deepEqual(literals('a { color: rgb(from var(--base) r g b / 0.5); }'), []);
});

test('reads numeric fallbacks inside a colour function var()', () => {
  assert.equal(literals('a { color: rgb(var(--brand, 255 0 0)); }').length, 1);
  assert.deepEqual(literals('a { color: rgb(var(--c) / var(--a, 1)); }'), []);
});

test('reads fixed channels in color(from) and every colour channel of a relative function', () => {
  assert.equal(literals('a { color: color(from var(--base) srgb r g 0); }').length, 1);
  assert.equal(literals('a { color: rgb(from var(--base) r 128 b); }').length, 1);
  assert.equal(literals('a { color: hsl(from var(--base) h none l); }').length, 1);
  assert.equal(literals('a { color: rgb(from var(--base) r g calc(255)); }').length, 1);
  assert.deepEqual(literals('a { color: color(from var(--base) srgb r g b / 0.5); }'), []);
  assert.deepEqual(literals('a { color: rgb(from var(--base) calc(r + 10) g b / 0.5); }'), []);
});

test('reads a channel triplet in a custom property', () => {
  assert.deepEqual(literals('a { --x: 255 0 0; }'), ['255 0 0']);
  assert.deepEqual(literals('a { --x: 0.5 0.2 1 / 0.4; }'), ['0.5 0.2 1 / 0.4']);
  assert.deepEqual(literals('a { --x: var(--a); --y: 1 2; --z: 0.5; }'), []);
  assert.deepEqual(literals('a { margin: 1 2 3; }'), []);
});

test('reads math function channels in a custom property triplet', () => {
  assert.deepEqual(literals('a { --brand: calc(255) 0 0; }'), ['calc(255) 0 0']);
  assert.deepEqual(literals('a { --brand: 255 MIN(100, 50 * 2) clamp(0, (1 + 2) * 3, 9); }'), [
    '255 MIN(100, 50 * 2) clamp(0, (1 + 2) * 3, 9)',
  ]);
  assert.deepEqual(literals('a { --brand: calc(100% - 10%), 0%, 0% / calc(0.5); }'), [
    'calc(100% - 10%), 0%, 0% / calc(0.5)',
  ]);
  assert.deepEqual(literals('a { --brand: var(--configured, calc(255) 0 0); }'), [
    'var(--configured, calc(255) 0 0)',
  ]);
  assert.deepEqual(literals('a { --brand: calc(min(100, max(0, 255))) 0 0; }'), [
    'calc(min(100, max(0, 255))) 0 0',
  ]);
  assert.deepEqual(literals('a { color: rgb(from var(--base, calc(255) 0 0) r g b); }'), [
    'rgb(from var(--base, calc(255) 0 0)',
  ]);
  assert.deepEqual(literals('a { --brand: calc(1e2) calc(pi * 10) 2.5E1; }'), [
    'calc(1e2) calc(pi * 10) 2.5E1',
  ]);
  assert.deepEqual(literals('a { --brand: calc(min(var(--r), max(0, 255))) 0 0; }'), []);
  assert.deepEqual(literals('a { --brand: round(down, 255) round(to-zero, 2.5, 1) 0; }'), [
    'round(down, 255) round(to-zero, 2.5, 1) 0',
  ]);
  assert.deepEqual(literals('a { color: rgb(from var(--base) calc(255) 0 0); }'), [
    'rgb(from var(--base) calc(255)',
  ]);
  assert.deepEqual(literals('a { --size: calc(1em + 1in) 0 0; }'), []);
  assert.deepEqual(literals('a { --brand: calc(var(--r)) 0 0; }'), []);
  assert.deepEqual(literals('a { --brand: calc(var(--r) * 2) 0 0; }'), []);
  assert.deepEqual(
    literals('a { --offset: calc(1px + 2px) 0 0; --size: max(1rem, 2vw) 0 0; }'),
    [],
  );
});

test('reads angle channels in a custom property triplet', () => {
  assert.deepEqual(literals('a { --brand: sin(90deg) 0 0; }'), ['sin(90deg) 0 0']);
  assert.deepEqual(literals('a { --h: 90deg 50% 50%; }'), ['90deg 50% 50%']);
  assert.deepEqual(literals('a { --h: 0.25turn 50% 50%; }'), ['0.25turn 50% 50%']);
  assert.deepEqual(literals('a { --h: calc(45deg * 2) 50% 50%; }'), ['calc(45deg * 2) 50% 50%']);
  assert.deepEqual(literals('a { --h: 120 50% cos(1rad); }'), ['120 50% cos(1rad)']);
  assert.deepEqual(literals('a { --h: sin(calc(90deg)) 0 0; }'), ['sin(calc(90deg)) 0 0']);
  assert.deepEqual(literals('a { --size: calc(1px + 2px) 0 0; }'), []);
  assert.deepEqual(literals('a { --size: calc(1deg + 2px) 0 0; }'), []);
  assert.deepEqual(literals('a { --h: sin(var(--angle)) 0 0; }'), []);
  assert.deepEqual(literals('a { --h: 0 90deg 0; }'), []);
});

test('reads rounding and other math functions over angles in a hue triplet', () => {
  assert.deepEqual(literals('a { --h: round(to-zero, 90deg, 1deg) 50% 50%; }'), [
    'round(to-zero, 90deg, 1deg) 50% 50%',
  ]);
  assert.deepEqual(literals('a { --h: round(up, 90.5deg) 50% 50%; }'), [
    'round(up, 90.5deg) 50% 50%',
  ]);
  assert.deepEqual(literals('a { --h: mod(400deg, 360deg) 50% 50%; }'), [
    'mod(400deg, 360deg) 50% 50%',
  ]);
  assert.deepEqual(literals('a { --h: atan2(1, 1) 50% 50%; }'), ['atan2(1, 1) 50% 50%']);
  assert.deepEqual(literals('a { --h: calc(pi * 1rad) 50% 50%; }'), ['calc(pi * 1rad) 50% 50%']);
  assert.deepEqual(literals('a { --h: round(future-strategy, 90deg) 50% 50%; }'), [
    'round(future-strategy, 90deg) 50% 50%',
  ]);
  assert.deepEqual(literals('a { --h: round(to-zero, 90px, 1px) 50% 50%; }'), []);
  assert.deepEqual(literals('a { --h: round(to-zero, var(--angle), 1deg) 50% 50%; }'), []);
  assert.deepEqual(literals('a { --h: env(hue, 90deg) 50% 50%; }'), []);
  assert.deepEqual(literals('a { --h: atan2(1px, 1px) 50% 50%; }'), ['atan2(1px, 1px) 50% 50%']);
  assert.deepEqual(literals('a { --brand: 255 sign(90deg) 0; }'), ['255 sign(90deg) 0']);
  assert.deepEqual(literals('a { --brand: 255 sign(-4px) 0; }'), ['255 sign(-4px) 0']);
  assert.deepEqual(literals('a { --h: calc(90deg + 1px) 50% 50%; }'), []);
  assert.deepEqual(literals('a { --orientation: 0 calc(90deg) 0; }'), []);
  assert.deepEqual(literals('a { --orientation: 0 round(to-zero, 90deg, 1deg) 0; }'), []);
  assert.deepEqual(literals('a { --orientation: 0 0 atan(1); }'), []);
  assert.deepEqual(literals('a { --h: calc(90deg) 50% 50%; }'), ['calc(90deg) 50% 50%']);
  assert.deepEqual(literals('a { --h: atan2(calc(1px + 1px), 1px) 50% 50%; }'), [
    'atan2(calc(1px + 1px), 1px) 50% 50%',
  ]);
  assert.deepEqual(literals('a { --brand: 255 sign(calc(-4px)) 0; }'), ['255 sign(calc(-4px)) 0']);
  assert.deepEqual(literals('a { --size: max(calc(1px + 1px), 2px) 0 0; }'), []);
});

test('a token source exempts its custom properties only', () => {
  const css = ':root { --x: 255 0 0; --y: #fff; }\na { color: #fff; width: calc(1 * 2); }';
  assert.deepEqual(findCssColorLiterals(css, [], true), [{ line: 2, literal: '#fff' }]);
});

test('reads literal origins and fallbacks of a relative colour', () => {
  assert.deepEqual(literals('a { color: rgb(from #ff0000 r g b); }'), ['#ff0000']);
  assert.deepEqual(literals('a { color: color(from #fff srgb r g b); }'), ['#fff']);
  assert.deepEqual(literals('a { color: rgb(from var(--base, #fff) r g b); }'), ['#fff']);
  assert.deepEqual(literals('a { color: rgb(from var(--base) r g b); }'), []);
  assert.deepEqual(literals('a { color: rgb(from var(--base) r g var(--channel, 255)); }'), [
    'rgb(from var(--base) r g var(--channel, 255)',
  ]);
  assert.deepEqual(literals('a { color: rgb(from var(--base) r g var(--channel)); }'), []);
  assert.deepEqual(literals('a { color: rgb(from var(--base, 255 0 0) r g b); }'), [
    'rgb(from var(--base, 255 0 0)',
  ]);
  assert.deepEqual(literals('a { color: rgb(from var(--base) r g var(--channel, none)); }'), [
    'rgb(from var(--base) r g var(--channel, none)',
  ]);
  assert.deepEqual(literals('a { --brand: 255 0 0 / var(--alpha); }'), ['255 0 0 / var(--alpha)']);
});

test('reads percentage channels and triplets inside a var() fallback', () => {
  assert.deepEqual(literals('a { --brand: 100% 0% 0%; }'), ['100% 0% 0%']);
  assert.deepEqual(literals('a { --brand: var(--configured, 255 0 0); }'), [
    'var(--configured, 255 0 0)',
  ]);
  assert.deepEqual(literals('a { --brand: 255, 0, 0; }'), ['255, 0, 0']);
  assert.deepEqual(literals('a { --brand: VAR(--configured, 255 0 0); }'), [
    'VAR(--configured, 255 0 0)',
  ]);
  assert.deepEqual(literals('a { --offset: 0 1px 2px; --size: 1.5rem 2rem 3rem; }'), []);
});

const { logger, SystemCapabilities } = require('@librechat/data-schemas');
const {
  checkAccess,
  assertModelBoundContent,
  createInstructionsPromptAccess,
} = require('@librechat/api');
const { Permissions, PermissionTypes } = require('librechat-data-provider');
const { getResourcePermissionsMap } = require('~/server/services/PermissionService');
const { hasCapability } = require('~/server/middleware/roles/capabilities');
const { promptService } = require('~/server/services/Prompts');
const db = require('~/models');

/**
 * Wiring only: the write/present decision logic lives in `@librechat/api`
 * (`createInstructionsPromptAccess`, `checkInstructionsPromptWrite`).
 */
const instructionsPromptAccess = createInstructionsPromptAccess({
  getResourcePermissionsMap,
  canManagePrompts: (user) => hasCapability(user, SystemCapabilities.MANAGE_PROMPTS),
  promptService,
  assertAgentInstructionsContent: ({ instructions, filters }) =>
    assertModelBoundContent({ filters, agents: [{ instructions }] }),
  /** The same role-level gate `checkPromptAccess` applies to every `/prompts` route
   *  (`PermissionTypes.PROMPTS`, `Permissions.USE`). Only `.role` is read, so the
   *  `{ id, role }` identity `validateLinkWrite` carries is enough. */
  canUsePrompts: (user, req) =>
    checkAccess({
      req,
      user,
      permissionType: PermissionTypes.PROMPTS,
      permissions: [Permissions.USE],
      getRoleByName: db.getRoleByName,
    }),
  logger,
});

module.exports = { instructionsPromptAccess };

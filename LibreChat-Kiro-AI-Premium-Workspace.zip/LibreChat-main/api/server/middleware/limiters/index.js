const createTTSLimiters = require('./ttsLimiters');
const createSTTLimiters = require('./sttLimiters');

const loginLimiter = require('./loginLimiter');
const passkeyLimiter = require('./passkeyLimiter');
const importLimiters = require('./importLimiters');
const uploadLimiters = require('./uploadLimiters');
const forkLimiters = require('./forkLimiters');
const shareLimiters = require('./shareLimiters');
const registerLimiter = require('./registerLimiter');
const toolCallLimiter = require('./toolCallLimiter');
const messageLimiters = require('./messageLimiters');
const promptUsageLimiter = require('./promptUsageLimiter');
const promptResolveLimiter = require('./promptResolveLimiter');
const verifyEmailLimiter = require('./verifyEmailLimiter');
const emailChangeLimiter = require('./emailChangeLimiter');
const emailChangeSubmissionLimiter = require('./emailChangeSubmissionLimiter');
const emailChangeSubmissionIpLimiter = require('./emailChangeSubmissionIpLimiter');
const resetPasswordLimiter = require('./resetPasswordLimiter');
const twoFactorTempLimiter = require('./twoFactorTempLimiter');
const passkeyStepUpLimiter = require('./passkeyStepUpLimiter');
const verifyEmailSubmissionLimiter = require('./verifyEmailSubmissionLimiter');
const resetPasswordSubmissionLimiter = require('./resetPasswordSubmissionLimiter');

const { twoFactorSetupLimiter } = twoFactorTempLimiter;

module.exports = {
  ...uploadLimiters,
  ...importLimiters,
  ...messageLimiters,
  ...forkLimiters,
  ...shareLimiters,
  ...promptUsageLimiter,
  ...promptResolveLimiter,
  loginLimiter,
  passkeyLimiter,
  passkeyStepUpLimiter,
  registerLimiter,
  toolCallLimiter,
  createTTSLimiters,
  createSTTLimiters,
  verifyEmailLimiter,
  emailChangeLimiter,
  emailChangeSubmissionLimiter,
  emailChangeSubmissionIpLimiter,
  resetPasswordLimiter,
  verifyEmailSubmissionLimiter,
  resetPasswordSubmissionLimiter,
  twoFactorTempLimiter,
  twoFactorSetupLimiter,
};
